 $(document).ready(function()
	{

		$('html body').localScroll({
		   target:'body'
		});
		
		
	});


            <p class="copyright">&copy; 2014 Copyright - <a href ="#">J.J. Fagan & Co., LLC.</a></p>   

            <a class="goup" href="#top" style="opacity: 5.2325;"> <p>&#8679; </p> <!--<img alt="Go Up" src="img/up_arrow.png">--></a>

        </div>





        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.2.min.js"><\/script>')</script>
        <script src="<?php bloginfo('template_url');?>/js/plugins.js"></script>
        <script src="<?php bloginfo('template_url');?>/js/main.js"></script>
        <script src="<?php bloginfo('template_url');?>/js/jquery.scrollTo-1.4.3.1-min.js" type="text/javascript"></script>
        <script src="<?php bloginfo('template_url');?>/js/jquery.localscroll-1.2.7-min.js" type="text/javascript"></script>
        <script src="<?php bloginfo('template_url');?>/js/scroll.js" type="text/javascript"></script>

        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='//www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X');ga('send','pageview');
        </script>

        <?php wp_footer(); ?>
    </body>
</html>

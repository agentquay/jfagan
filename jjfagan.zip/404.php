<?php get_header(); ?>

	<article>
		<h1>404 Not Found</h1>
		<p>Apologies, but the page you requested could not be found. Perhaps searching will help.</p>
		<?php get_search_form(); ?>
	</article>

<?php get_footer(); ?>